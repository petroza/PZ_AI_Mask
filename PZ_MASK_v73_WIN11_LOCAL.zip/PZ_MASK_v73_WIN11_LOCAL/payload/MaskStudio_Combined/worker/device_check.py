#!/usr/bin/env python3
import json
import os
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

cfg_path = Path(__file__).with_name("config.json")
try:
    import torch
    print("Torch:", torch.__version__)
    print("Torch CUDA build:", getattr(torch.version, "cuda", None))
    print("torch.cuda.is_available:", torch.cuda.is_available())
    if torch.cuda.is_available():
        print("GPU:", torch.cuda.get_device_name(0))
except Exception as exc:
    print("[ERROR] PyTorch check failed:", exc)
    sys.exit(2)

# Keep config sane. Use AUTO by default so a copied config does not crash.
try:
    if cfg_path.exists():
        cfg = json.loads(cfg_path.read_text(encoding="utf-8-sig"))
        dev = str(cfg.get("device", "auto") or "auto").lower()
        if dev not in ("auto", "cuda", "cpu"):
            cfg["device"] = "auto"
        cfg_path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
except Exception as exc:
    print("[WARN] Config check skipped:", exc)

if not torch.cuda.is_available():
    print("[WARN] CUDA není dostupná. Pro RTX spusť nastroje\\REPAIR_CUDA_TORCH.bat.")
    sys.exit(1)
print("[OK] CUDA je připravená.")
