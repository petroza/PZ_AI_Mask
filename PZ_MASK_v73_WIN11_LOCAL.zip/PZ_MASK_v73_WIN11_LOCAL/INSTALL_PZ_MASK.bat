@echo off
REM ====================================================================
REM  PZ MASK v73 WIN11 LOCAL - installer with Windows folder picker
REM  Pure CMD + a temporary VBS dialog. No PowerShell required.
REM  Installs a fully local app. Main start after install: START.bat
REM ====================================================================
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"

set "SRC=%~dp0payload\MaskStudio_Combined"
if "%SRC:~-1%"=="\" set "SRC=%SRC:~0,-1%"

echo.
echo  ============================================================
echo    PZ MASK v73 - install (local, Windows 11)
echo  ============================================================
echo.
echo  This installs a LOCAL app. Nothing is uploaded to any website.
echo  The browser address after install is http://127.0.0.1:8080
echo.
echo  In the next window choose the target folder (a short path without
echo  diacritics is best, e.g. C:\PZ_MASK).
echo.
echo  First install downloads several GB (PyTorch CUDA, models, PHP) and
echo  needs internet. After that the app works offline.
echo.
echo  Main start file after install:  START.bat
echo  Repair/diagnostic tools live in: nastroje\
echo.

if not exist "%SRC%\nastroje\INSTALL_NO_POWERSHELL.bat" (
  echo  [ERROR] Payload missing: %SRC%
  echo  Extract the WHOLE ZIP first, then run this installer again.
  pause
  exit /b 1
)

set "DEFAULT_TARGET=%USERPROFILE%\PZ_MASK"

echo  Opening Windows folder selection window...
echo.

set "PICKER=%TEMP%\pzmask_folder_picker_%RANDOM%%RANDOM%.vbs"
set "OUTTXT=%TEMP%\pzmask_selected_folder_%RANDOM%%RANDOM%.txt"

> "%PICKER%" echo Option Explicit
>>"%PICKER%" echo Dim sh, fso, f, outFile
>>"%PICKER%" echo Set sh = CreateObject("Shell.Application")
>>"%PICKER%" echo Set fso = CreateObject("Scripting.FileSystemObject")
>>"%PICKER%" echo outFile = WScript.Arguments(0)
>>"%PICKER%" echo Set f = sh.BrowseForFolder(0, "Select the target folder for PZ MASK installation", ^&H0051, 17)
>>"%PICKER%" echo If Not f Is Nothing Then
>>"%PICKER%" echo   fso.CreateTextFile(outFile, True).Write f.Self.Path
>>"%PICKER%" echo End If

start /wait "" wscript.exe "%PICKER%" "%OUTTXT%"

set "TARGET="
if exist "%OUTTXT%" (
  set /p TARGET=<"%OUTTXT%"
)

del "%PICKER%" >nul 2>nul
del "%OUTTXT%" >nul 2>nul

if "%TARGET%"=="" (
  echo.
  echo  No folder selected.
  echo  Default target:
  echo    %DEFAULT_TARGET%
  echo.
  choice /C YN /M "Use the default target folder"
  if errorlevel 2 (
    set /p "TARGET=Type target folder path manually: "
  ) else (
    set "TARGET=%DEFAULT_TARGET%"
  )
)

if "%TARGET%"=="" (
  echo  [ERROR] No target folder selected.
  pause
  exit /b 1
)

if "%TARGET:~0,1%"=="^"" set "TARGET=%TARGET:~1%"
if "%TARGET:~-1%"=="^"" set "TARGET=%TARGET:~0,-1%"

echo.
echo  Selected target:
echo    %TARGET%
echo.
if exist "%TARGET%" (
  echo  Folder exists. Existing app files may be overwritten.
  choice /C YN /M "Continue"
  if errorlevel 2 exit /b 1
) else (
  mkdir "%TARGET%" >nul 2>nul
  if errorlevel 1 (
    echo  [ERROR] Cannot create target folder.
    pause
    exit /b 1
  )
)

echo.
echo  [1/4] Copying application files...
robocopy "%SRC%" "%TARGET%" /E /NFL /NDL /NJH /NJS /NP >nul
set "RC=%ERRORLEVEL%"
if %RC% GEQ 8 (
  echo  [ERROR] Copy failed. Robocopy code %RC%.
  pause
  exit /b 1
)

echo.
echo  [2/4] Installing runtime into the target folder (Python, PHP, models)...
echo        This can take a while and needs internet. Keep the window open.
echo.
pushd "%TARGET%"
call "%TARGET%\nastroje\INSTALL_NO_POWERSHELL.bat"
set "INSTALL_RC=%ERRORLEVEL%"
popd
if not "%INSTALL_RC%"=="0" (
  echo.
  echo  [ERROR] Runtime install failed with code %INSTALL_RC%.
  echo          The target folder is left intact for debugging.
  pause
  exit /b %INSTALL_RC%
)

echo.
echo  [3/4] Cleaning target folder (keep stable launchers only)...
for %%B in ("%TARGET%\*.bat") do (
  if /I not "%%~nxB"=="START.bat" if /I not "%%~nxB"=="STOP_PZ_MASK.bat" if /I not "%%~nxB"=="UNINSTALL.bat" del /q "%%~fB" >nul 2>nul
)
if exist "%TARGET%\installer.ps1" del /q "%TARGET%\installer.ps1" >nul 2>nul
for %%R in ("%TARGET%\README*.txt" "%TARGET%\README*.md" "%TARGET%\README.md") do if exist "%%~fR" del /q "%%~fR" >nul 2>nul

echo.
echo  [4/4] Done.
echo.
echo  ============================================================
echo    Installation complete.
echo.
echo    Start the app from:
echo      %TARGET%\START.bat
echo    Then open in your browser:
echo      http://127.0.0.1:8080
echo.
echo    To remove the app later:
echo      %TARGET%\UNINSTALL.bat
echo  ============================================================
echo.
pause
exit /b 0
