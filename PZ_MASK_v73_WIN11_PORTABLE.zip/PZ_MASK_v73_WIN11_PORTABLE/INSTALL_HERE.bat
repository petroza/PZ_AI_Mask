@echo off
REM ====================================================================
REM  PZ MASK v73 WIN11 PORTABLE - install the runtime INTO THIS FOLDER
REM  No admin, no Program Files, no registry. Pure CMD (no PowerShell).
REM ====================================================================
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"

echo.
echo  ============================================================
echo    PZ MASK v73 - portable install (into this folder)
echo  ============================================================
echo.
echo  Everything is installed into this folder under .\runtime
echo  No admin rights, nothing in Program Files or the registry.
echo  To uninstall later: just delete this folder, or run UNINSTALL.bat
echo.
echo  The first install downloads several GB (PyTorch CUDA, models, PHP)
echo  and needs internet. After that the app runs offline.
echo.

if not exist "%~dp0nastroje\INSTALL_NO_POWERSHELL.bat" (
  echo  [ERROR] Files are missing. Extract the WHOLE ZIP first, then run this again.
  pause
  exit /b 1
)

call "%~dp0nastroje\INSTALL_NO_POWERSHELL.bat"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
  echo.
  echo  [ERROR] Install failed with code %RC%. See the messages above.
  pause
  exit /b %RC%
)

echo.
echo  ============================================================
echo    Done. Start the app with START.bat in this folder.
echo    Then open http://127.0.0.1:8080  (use 127.0.0.1, not localhost)
echo  ============================================================
echo.
pause
exit /b 0
