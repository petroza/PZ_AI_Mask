@echo off
REM ====================================================================
REM  PZ MASK v73 WIN11 LOCAL - stop local frontend/worker
REM ====================================================================
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
echo.
echo ============================================================
echo   Stopping PZ MASK local processes
echo ============================================================
echo.

echo [1/4] Closing PZ MASK windows by title (frontend + worker)...
taskkill /FI "WINDOWTITLE eq PZ MASK - FRONTEND*" /T /F >nul 2>nul
taskkill /FI "WINDOWTITLE eq PZ MASK - WORKER*" /T /F >nul 2>nul

echo [2/4] Trying to stop PHP frontend on port 8080...
for /f "tokens=5" %%P in ('netstat -ano ^| findstr ":8080 " ^| findstr "LISTENING"') do (
  echo Killing PID %%P on port 8080
  taskkill /PID %%P /F >nul 2>nul
)

echo [3/4] Fallback: stop worker python started from this folder...
REM WMIC is deprecated/removed on newer Windows 11. The title-based kill above
REM is the primary method; this WMIC pass is a best-effort fallback only.
for /f "skip=1 tokens=2 delims==" %%P in ('wmic process where "name='python.exe' and commandline like '%%%CD:\=\\%%%worker\\run.py%%'" get ProcessId /value 2^>nul ^| find "="') do (
  echo Killing worker PID %%P
  taskkill /PID %%P /F >nul 2>nul
)

echo [4/4] Done.
echo.
pause
exit /b 0
