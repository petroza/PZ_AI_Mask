@echo off
REM ====================================================================
REM  PZ MASK v73 WIN11 LOCAL - smooth local start (force 127.0.0.1)
REM  - No 20s blocking wait for the API.
REM  - Does NOT force-kill port 8080. Reuses a server that is already up.
REM  - Start frontend -> open browser -> start worker (worker retries).
REM ====================================================================
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"

set "HERE=%~dp0"
if "%HERE:~-1%"=="\" set "HERE=%HERE:~0,-1%"

set "HOST=127.0.0.1"
set "PORT=8080"
set "URL=http://%HOST%:%PORT%"
set "APIURL=%URL%/api/index.php?action="
set "PHPEXE=%HERE%\runtime\php\php.exe"
set "PHPINI=%HERE%\runtime\php\php.ini"
set "PYEXE=%HERE%\runtime\miniconda\envs\maskstudio\python.exe"
if exist "%HERE%\worker\python_path.txt" set /p PYEXE=<"%HERE%\worker\python_path.txt"

echo.
echo ============================================================
echo   PZ MASK v73  -  local start
echo   URL: %URL%   (use 127.0.0.1, not localhost)
echo ============================================================
echo Folder: %HERE%
echo.

if not exist "%PHPEXE%" goto nophp
if not exist "%PYEXE%" goto noenv
if not exist "%HERE%\worker\config.json" goto nocfg

if not exist "%HERE%\runtime\_launcher" mkdir "%HERE%\runtime\_launcher" >nul 2>nul
if not exist "%HERE%\runtime\logs" mkdir "%HERE%\runtime\logs" >nul 2>nul

echo [1/5] Forcing worker API base to %APIURL%
"%PYEXE%" "%HERE%\tools\fix_api_base_127001.py" "%HERE%\worker\config.json" "%APIURL%" >nul 2>nul

set "FRONTBAT=%HERE%\runtime\_launcher\frontend_v73.cmd"
set "WORKBAT=%HERE%\runtime\_launcher\worker_v73.cmd"

REM --- frontend launcher, bind directly to 127.0.0.1
> "%FRONTBAT%" echo @echo off
>>"%FRONTBAT%" echo title PZ MASK - FRONTEND
>>"%FRONTBAT%" echo cd /d "%HERE%"
>>"%FRONTBAT%" echo echo.
>>"%FRONTBAT%" echo echo ============================================================
>>"%FRONTBAT%" echo echo   PZ MASK frontend/server
>>"%FRONTBAT%" echo echo   URL: %URL%
>>"%FRONTBAT%" echo echo   Bound to: %HOST%:%PORT%
>>"%FRONTBAT%" echo echo   Close this window to stop the frontend.
>>"%FRONTBAT%" echo echo ============================================================
>>"%FRONTBAT%" echo echo.
>>"%FRONTBAT%" echo "%PHPEXE%" -c "%PHPINI%" -S %HOST%:%PORT% -t "%HERE%" "%HERE%\router.php"
>>"%FRONTBAT%" echo echo.
>>"%FRONTBAT%" echo echo Frontend stopped.
>>"%FRONTBAT%" echo pause

REM --- worker launcher
> "%WORKBAT%" echo @echo off
>>"%WORKBAT%" echo title PZ MASK - WORKER
>>"%WORKBAT%" echo set PYTHONUTF8=1
>>"%WORKBAT%" echo set "HF_HOME=%HERE%\runtime\hf_cache"
>>"%WORKBAT%" echo if exist "%HERE%\worker\hf_token.txt" ^(
>>"%WORKBAT%" echo   set /p HF_TOKEN=^<"%HERE%\worker\hf_token.txt"
>>"%WORKBAT%" echo   set "HUGGINGFACE_HUB_TOKEN=%%HF_TOKEN%%"
>>"%WORKBAT%" echo   echo [OK] Hugging Face token loaded from worker\hf_token.txt
>>"%WORKBAT%" echo ^)
>>"%WORKBAT%" echo cd /d "%HERE%"
>>"%WORKBAT%" echo echo.
>>"%WORKBAT%" echo echo ============================================================
>>"%WORKBAT%" echo echo   PZ MASK worker
>>"%WORKBAT%" echo echo   API: %APIURL%
>>"%WORKBAT%" echo echo   Close this window to stop the worker.
>>"%WORKBAT%" echo echo ============================================================
>>"%WORKBAT%" echo echo.
>>"%WORKBAT%" echo "%PYEXE%" "%HERE%\tools\fix_api_base_127001.py" "%HERE%\worker\config.json" "%APIURL%"
>>"%WORKBAT%" echo echo Checking PyTorch/CUDA...
>>"%WORKBAT%" echo "%PYEXE%" "%HERE%\worker\device_check.py"
>>"%WORKBAT%" echo if errorlevel 1 ^(
>>"%WORKBAT%" echo   echo.
>>"%WORKBAT%" echo   echo [WARN] CUDA check failed. Worker will still start and print details.
>>"%WORKBAT%" echo   echo.
>>"%WORKBAT%" echo ^)
>>"%WORKBAT%" echo echo Starting worker...
>>"%WORKBAT%" echo "%PYEXE%" "%HERE%\worker\run.py" --config "%HERE%\worker\config.json"
>>"%WORKBAT%" echo echo.
>>"%WORKBAT%" echo echo Worker stopped.
>>"%WORKBAT%" echo pause

echo [2/4] Checking whether the server is already running...
curl.exe --ipv4 --connect-timeout 1 --max-time 2 -fsS "%APIURL%" >nul 2>nul
if not errorlevel 1 goto server_up

REM Port busy but API not answering = a stale/foreign process. Do NOT force-kill.
netstat -ano | findstr ":%PORT% " | findstr "LISTENING" >nul 2>nul
if not errorlevel 1 (
  echo.
  echo [!] Port %PORT% is in use but the PZ MASK API did not answer.
  echo     If the app seems stuck, run STOP_PZ_MASK.bat first, then START.bat again.
  echo.
)

echo [3/4] Starting frontend/server on %URL% ...
start "PZ MASK - FRONTEND" "%FRONTBAT%"

REM Quick, non-blocking readiness poll (max ~8s; usually ready in ~1s).
set /a tries=0
:wait_api
timeout /t 1 /nobreak >nul
curl.exe --ipv4 --connect-timeout 1 --max-time 2 -fsS "%APIURL%" >nul 2>nul
if not errorlevel 1 goto api_ready
set /a tries+=1
if %tries% GEQ 8 goto api_slow
goto wait_api

:api_slow
echo       API is slow to start - opening browser anyway. Check the FRONTEND window.
goto open_browser

:api_ready
echo       API OK on %APIURL%

:open_browser
echo [4/4] Opening browser and starting worker...
start "" "%URL%"
start "PZ MASK - WORKER" "%WORKBAT%"
echo.
echo ============================================================
echo   PZ MASK is starting on %URL%
echo   Two windows opened: FRONTEND and WORKER - keep them open.
echo   Important: use 127.0.0.1, not localhost.
echo   To stop everything: STOP_PZ_MASK.bat
echo ============================================================
echo.
pause
exit /b 0

:server_up
echo       Server already running - PZ MASK is up.
echo [4/4] Opening browser at %URL% ...
start "" "%URL%"
echo.
echo ============================================================
echo   PZ MASK already running on %URL% - opened the browser.
echo   Did not start a second server/worker.
echo   If processing seems dead, run STOP_PZ_MASK.bat then START.bat.
echo ============================================================
echo.
pause
exit /b 0

:nophp
echo [ERROR] PHP runtime not found:
echo         %PHPEXE%
echo Run the installer first (INSTALL_PZ_MASK.bat from the ZIP).
pause
exit /b 1

:noenv
echo [ERROR] Python runtime not found:
echo         %PYEXE%
echo Run the installer first (INSTALL_PZ_MASK.bat from the ZIP).
pause
exit /b 1

:nocfg
echo [ERROR] Missing worker\config.json.
echo Run the installer first (INSTALL_PZ_MASK.bat from the ZIP).
pause
exit /b 1
