#!/usr/bin/env python3
"""
Stahne SAM 2.1 checkpointy do ./checkpoints.
MatAnyone checkpoint si stahni dle instrukci v jeho repu (Hugging Face) ?
odkaz je v README; sem ho jen zkopiruj jako checkpoints/matanyone.pth.

Pouziti:
    python download_models.py            # stahne base_plus (default na 12 GB)
    python download_models.py --all      # stahne vsechny velikosti
    python download_models.py --models large base_plus
"""
import os
import sys
import argparse
import urllib.request

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

BASE = "https://dl.fbaipublicfiles.com/segment_anything_2/092824"
SAM21 = {
    "hiera_tiny":      "sam2.1_hiera_tiny.pt",
    "hiera_small":     "sam2.1_hiera_small.pt",
    "hiera_base_plus": "sam2.1_hiera_base_plus.pt",
    "hiera_large":     "sam2.1_hiera_large.pt",
}
ALIASES = {
    "tiny": "hiera_tiny",
    "small": "hiera_small",
    "base": "hiera_base_plus",
    "base_plus": "hiera_base_plus",
    "large": "hiera_large",
}


def dl(url, dest):
    if os.path.exists(dest) and os.path.getsize(dest) > 0:
        mb = os.path.getsize(dest) / (1024 * 1024)
        print(f"  [OK] uz existuje: {os.path.basename(dest)} ({mb:.0f} MB)")
        return
    print(f"  stahuji: {os.path.basename(dest)}")
    tmp = dest + ".part"

    def hook(blocks, bs, total):
        got = blocks * bs
        got_mb = got / (1024 * 1024)
        if total > 0:
            pct = min(100, int(got * 100 / total))
            tot_mb = total / (1024 * 1024)
            sys.stdout.write(f"\r    {pct:3d}%  {got_mb:6.1f} / {tot_mb:.1f} MB   ")
        else:
            sys.stdout.write(f"\r    {got_mb:6.1f} MB   ")
        sys.stdout.flush()

    urllib.request.urlretrieve(url, tmp, hook)
    os.replace(tmp, dest)
    print("\n  [OK] hotovo")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--models", nargs="*", default=["hiera_base_plus"])
    ap.add_argument("--matanyone2", action="store_true",
                    help="stahni i MatAnyone 2 checkpoint (jinak se stahne z HF pri behu)")
    ap.add_argument("--dir", default="./checkpoints")
    args = ap.parse_args()

    os.makedirs(args.dir, exist_ok=True)
    raw_keys = list(SAM21.keys()) if args.all else args.models
    keys = []
    for k in raw_keys:
        kk = ALIASES.get(k, k)
        if kk not in keys:
            keys.append(kk)
    print(f"Stahuji SAM 2.1 modely do {args.dir}: {', '.join(keys)}")
    for k in keys:
        if k not in SAM21:
            print(f"  ! neznamy model: {k} (povolene: {', '.join(list(SAM21)+list(ALIASES))})")
            continue
        dl(f"{BASE}/{SAM21[k]}", os.path.join(args.dir, SAM21[k]))

    print("\nSAM 2.1 hotovo.")
    print("MatAnyone 2: checkpoint se stahne automaticky z HuggingFace pri prvnim")
    print("  behu (PeiqingYang/MatAnyone2). Pro offline/pinned verzi stahni rucne:")
    print("  https://github.com/pq-yang/MatAnyone2/releases/download/v1.0.0/matanyone2.pth")
    print(f"  a uloz jako {os.path.join(args.dir, 'matanyone2.pth')}")

    if args.matanyone2:
        url = "https://github.com/pq-yang/MatAnyone2/releases/download/v1.0.0/matanyone2.pth"
        print("\nStahuji MatAnyone 2 checkpoint...")
        try:
            dl(url, os.path.join(args.dir, "matanyone2.pth"))
        except Exception as e:
            print(f"  ! stazeni selhalo ({e}); stahne se automaticky z HF pri behu.")


if __name__ == "__main__":
    main()
