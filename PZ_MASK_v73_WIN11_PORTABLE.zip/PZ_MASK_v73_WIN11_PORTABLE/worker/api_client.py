"""
PZ Mask Studio — REST klient pro worker.
Komunikuje s PHP API (claim, progress, result-meta, fail) a stahuje uploady.
"""
import json
import time
import os
import requests


class ApiClient:
    def __init__(self, cfg: dict):
        self.base = cfg["api_base"].rstrip()
        self.token = cfg["worker_token"]
        self.worker_id = cfg.get("worker_id", "worker")
        self.s = requests.Session()
        self.s.headers.update({"X-Worker-Token": self.token})

    def _url(self, action: str) -> str:
        # api_base končí na "...index.php?action="
        return self.base + action

    def claim(self):
        """Atomicky převezme 1 job (queued nebo created). Vrátí dict nebo None."""
        r = self.s.post(self._url("worker/claim"),
                        json={"worker_id": self.worker_id}, timeout=30)
        r.raise_for_status()
        d = r.json()
        return d.get("job")

    def get_job(self, job_id: int):
        r = self.s.get(self._url("worker/job") + f"&id={job_id}", timeout=30)
        r.raise_for_status()
        return r.json().get("job")

    def progress(self, job_id: int, *, status=None, progress=None, stage_msg=None,
                 frame_count=None, width=None, height=None, fps=None):
        payload = {"id": job_id}
        for k, v in dict(status=status, progress=progress, stage_msg=stage_msg,
                         frame_count=frame_count, width=width, height=height,
                         fps=fps).items():
            if v is not None:
                payload[k] = v
        try:
            self.s.post(self._url("worker/progress"), json=payload, timeout=30)
        except Exception as e:
            print(f"[api] progress selhal: {e}")


    def worker_status(self, payload: dict):
        """Pošle malý heartbeat se stavem GPU/VRAM/CPU/RAM pro editor."""
        try:
            self.s.post(self._url("worker/status"), json=payload, timeout=5)
        except Exception:
            # heartbeat nesmí brzdit ani shazovat worker
            pass

    def result_meta(self, job_id: int, stage_msg="Hotovo"):
        r = self.s.post(self._url("worker/result-meta"),
                        json={"id": job_id, "stage_msg": stage_msg}, timeout=30)
        r.raise_for_status()
        return r.json()

    def fail(self, job_id: int, error: str):
        try:
            self.s.post(self._url("worker/fail"),
                        json={"id": job_id, "error": error}, timeout=30)
        except Exception as e:
            print(f"[api] fail report selhal: {e}")

    # ---- přenos souborů ----------------------------------------------------
    def download_upload(self, source_path: str, dest: str):
        """
        Stáhne původní upload. source_path je relativní k storage/uploads,
        servírujeme ho přes statickou cestu /maskstudio/storage/uploads/<file>.
        """
        # api_base = ".../maskstudio/api/index.php?action="  → root = ".../maskstudio/"
        root = self.base.split("/api/")[0]
        url = f"{root}/storage/uploads/{source_path}"
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        with self.s.get(url, stream=True, timeout=300) as r:
            r.raise_for_status()
            with open(dest, "wb") as f:
                for chunk in r.iter_content(1 << 20):
                    f.write(chunk)
        return dest


    def source_video_url(self, token: str) -> str:
        """URL původního videa přes API; používá se pro rychlý single-frame preview bez downloadu celého videa."""
        return self._url("source-video") + f"&token={token}"

    def download_source_video_by_token(self, token: str, dest: str):
        """Nouzový fallback: stáhne původní video přes tokenizovaný API stream."""
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        with self.s.get(self.source_video_url(token), stream=True, timeout=600) as r:
            r.raise_for_status()
            with open(dest, "wb") as f:
                for chunk in r.iter_content(1 << 20):
                    if chunk:
                        f.write(chunk)
        return dest

    def upload_frames_zip(self, job_id: int, zip_path: str):
        """Nahraje ZIP s náhledovými JPG framy (pro zobrazení v editoru)."""
        with open(zip_path, "rb") as f:
            files = {"frames": (os.path.basename(zip_path), f, "application/zip")}
            r = self.s.post(self._url("worker/upload-frames") + f"&id={job_id}",
                            files=files, timeout=600)
        r.raise_for_status()
        return r.json()

    def upload_result_zip(self, job_id: int, zip_path: str):
        """Nahraje hotový ZIP zpět na server (endpoint worker/upload-result)."""
        return self.upload_result_file(job_id, zip_path, field="zip")

    def upload_result_file(self, job_id: int, path: str, field: str = "file"):
        """Nahraje hotový výsledný soubor (mp4 / mov / zip) zpět na server.

        Pro H.264/ProRes posíláme surový soubor (ne ZIP), aby šel rovnou
        stáhnout. PNG sekvence se posílá jako zip.
        """
        ctype = "application/octet-stream"
        low = path.lower()
        if low.endswith(".mp4"):
            ctype = "video/mp4"
        elif low.endswith(".mov"):
            ctype = "video/quicktime"
        elif low.endswith(".zip"):
            ctype = "application/zip"
        with open(path, "rb") as f:
            files = {field: (os.path.basename(path), f, ctype)}
            r = self.s.post(self._url("worker/upload-result") + f"&id={job_id}",
                            files=files, timeout=1200)
        r.raise_for_status()
        return r.json()

    def download_brush(self, token: str, brush_path: str, dest: str):
        root = self.base.split("/api/")[0]
        url = f"{root}/storage/jobs/{token}/{brush_path}"
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        with self.s.get(url, stream=True, timeout=120) as r:
            r.raise_for_status()
            with open(dest, "wb") as f:
                for chunk in r.iter_content(1 << 20):
                    f.write(chunk)
        return dest

    # ---- náhledy masky (interaktivní, single-frame) ------------------------
    def claim_preview(self):
        """Atomicky převezme 1 čekající náhledový požadavek. Vrátí dict/None."""
        r = self.s.post(self._url("worker/preview-claim"),
                        json={"worker_id": self.worker_id}, timeout=30)
        try:
            r.raise_for_status()
        except requests.HTTPError as e:
            body = (r.text or "").strip().replace("\n", " ")[:700]
            raise requests.HTTPError(f"{e} | API body: {body}", response=r)
        return r.json().get("preview")

    def upload_preview_mask(self, preview_id: int, png_path: str):
        """Nahraje hotovou náhledovou masku (PNG) zpět na server."""
        with open(png_path, "rb") as f:
            files = {"mask": (os.path.basename(png_path), f, "image/png")}
            r = self.s.post(self._url("worker/preview-result") + f"&id={preview_id}",
                            files=files, timeout=120)
        r.raise_for_status()
        return r.json()

    def fail_preview(self, preview_id: int, error: str):
        try:
            self.s.post(self._url("worker/preview-fail"),
                        json={"id": preview_id, "error": error}, timeout=30)
        except Exception as e:
            print(f"[api] preview fail report selhal: {e}")

    def download_preview_frame(self, token: str, i: int, dest: str):
        """Stáhne náhledový JPG frame ze serveru (fallback, když worker nemá full framy)."""
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        url = self._url("frame") + f"&token={token}&i={i}"
        with self.s.get(url, stream=True, timeout=60) as r:
            r.raise_for_status()
            with open(dest, "wb") as f:
                for chunk in r.iter_content(1 << 20):
                    f.write(chunk)
        return dest
