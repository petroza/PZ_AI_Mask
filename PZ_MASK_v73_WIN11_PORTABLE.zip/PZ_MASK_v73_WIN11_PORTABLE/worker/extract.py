"""
PZ Mask Studio — extrakce framů.

Robustní Windows verze:
  - když je dostupný FFmpeg/ffprobe, použije ho,
  - když FFmpeg není v PATH nebo chybí ffprobe.exe, automaticky přepne na OpenCV,
  - pokud je nainstalované imageio-ffmpeg, umí použít jeho přibalený ffmpeg.exe,
  - chyba už nespadne na FileNotFoundError: [WinError 2] bez vysvětlení.

Vstup může být:
  - video (mp4/mov/…)  → PNG framy + JPG náhledy
  - image sekvence      → číslované snímky vedle vstupu nebo jeden snímek

Worker po extrakci:
  - uloží plné framy do work_dir/frames_full/  (PNG, pro výpočet)
  - vyrobí JPG náhledy work_dir/frames_prev/   (pro editor v prohlížeči)
  - vrátí (frame_count, width, height, fps)
"""
import os
import glob
import json
import shutil
import subprocess
import zipfile

import cv2  # noqa: opencv-python


VIDEO_EXTS = {".mp4", ".mov", ".m4v", ".avi", ".mkv", ".webm", ".mpeg", ".mpg"}


def _quote_cmd(cmd):
    return " ".join(('"%s"' % c) if (" " in str(c) and not str(c).startswith('"')) else str(c) for c in cmd)


def _run(cmd):
    """Spustí externí příkaz a vrátí stdout. FileNotFoundError převede na srozumitelnou chybu."""
    try:
        p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    except FileNotFoundError as e:
        raise FileNotFoundError(
            "Nenalezen externí program: %s. "
            "Nainstaluj FFmpeg, nastav worker/config.json -> ffmpeg na ffmpeg.exe, "
            "nebo nech worker použít OpenCV fallback." % cmd[0]
        ) from e
    if p.returncode != 0:
        raise RuntimeError("Příkaz selhal: %s\n%s" % (_quote_cmd(cmd), p.stderr.decode("utf-8", "ignore")))
    return p.stdout.decode("utf-8", "ignore")


def _is_exe(path):
    return bool(path) and os.path.isfile(path) and path.lower().endswith(".exe")


def _resolve_ffmpeg(cfg):
    """
    Vrátí absolutní cestu k ffmpeg.exe nebo None.
    Podporuje:
      - config.json: "ffmpeg": "C:/.../ffmpeg.exe"
      - config.json: "ffmpeg": "ffmpeg" a PATH
      - env FFMPEG_BIN / IMAGEIO_FFMPEG_EXE
      - imageio_ffmpeg wheel
      - ./runtime/ffmpeg/bin/ffmpeg.exe
    """
    val = (cfg.get("ffmpeg") or "ffmpeg").strip()

    # 1) explicitní cesta v configu
    if val and val.lower() not in {"ffmpeg", "ffmpeg.exe", "auto"}:
        val2 = os.path.expandvars(os.path.expanduser(val.strip('"')))
        if os.path.isfile(val2):
            return os.path.abspath(val2)
        found = shutil.which(val2)
        if found:
            return found

    # 2) env proměnné
    for env_name in ("FFMPEG_BIN", "IMAGEIO_FFMPEG_EXE"):
        p = os.environ.get(env_name, "").strip('"')
        if os.path.isfile(p):
            return os.path.abspath(p)

    # 3) PATH
    found = shutil.which(val) or shutil.which("ffmpeg") or shutil.which("ffmpeg.exe")
    if found:
        return found

    # 4) lokální runtime složky vedle projektu / workeru
    here = os.path.abspath(os.path.dirname(__file__))
    root = os.path.abspath(os.path.join(here, ".."))
    candidates = [
        os.path.join(root, "runtime", "ffmpeg", "bin", "ffmpeg.exe"),
        os.path.join(root, "runtime", "ffmpeg", "ffmpeg.exe"),
        os.path.join(here, "ffmpeg.exe"),
    ]
    for p in candidates:
        if os.path.isfile(p):
            return os.path.abspath(p)

    # 5) imageio-ffmpeg má často přibalené ffmpeg.exe přímo ve wheelu
    try:
        import imageio_ffmpeg  # type: ignore
        p = imageio_ffmpeg.get_ffmpeg_exe()
        if os.path.isfile(p):
            return os.path.abspath(p)
    except Exception:
        pass

    return None


def _ffprobe_from_ffmpeg(ffmpeg_path):
    if not ffmpeg_path:
        return None
    d = os.path.dirname(ffmpeg_path)
    base = os.path.basename(ffmpeg_path)
    candidates = [
        os.path.join(d, "ffprobe.exe"),
        os.path.join(d, "ffprobe"),
        ffmpeg_path.replace("ffmpeg.exe", "ffprobe.exe").replace("ffmpeg", "ffprobe"),
    ]
    for p in candidates:
        if os.path.isfile(p) or shutil.which(p):
            return p
    found = shutil.which("ffprobe") or shutil.which("ffprobe.exe")
    return found


def _probe_video_cv2(path):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise RuntimeError("Video se nepodařilo otevřít přes OpenCV: %s" % path)
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
    fps = float(cap.get(cv2.CAP_PROP_FPS) or 0) or 25.0
    cap.release()
    if w <= 0 or h <= 0:
        raise RuntimeError("Nelze zjistit rozměry videa: %s" % path)
    return w, h, fps


def probe_video(cfg_or_ffmpeg, path):
    """Zjistí fps a rozměry. Preferuje ffprobe, při chybě použije OpenCV."""
    if isinstance(cfg_or_ffmpeg, dict):
        ffmpeg = _resolve_ffmpeg(cfg_or_ffmpeg)
    else:
        ffmpeg = cfg_or_ffmpeg

    ffprobe = _ffprobe_from_ffmpeg(ffmpeg)
    if ffprobe:
        try:
            out = _run([ffprobe, "-v", "error", "-select_streams", "v:0",
                        "-show_entries", "stream=width,height,r_frame_rate,nb_frames",
                        "-of", "json", path])
            streams = json.loads(out).get("streams") or []
            if streams:
                info = streams[0]
                w, h = int(info["width"]), int(info["height"])
                rate = info.get("r_frame_rate") or "25/1"
                num, den = rate.split("/")
                fps = float(num) / float(den) if float(den) else 25.0
                return w, h, fps
        except Exception as e:
            print(f"[extract] ffprobe selhal, přepínám na OpenCV probe: {e}")

    return _probe_video_cv2(path)


def _cfg_int(cfg, key, default, lo=None, hi=None):
    try:
        v = int(cfg.get(key, default)) if isinstance(cfg, dict) else int(default)
    except Exception:
        v = int(default)
    if lo is not None:
        v = max(lo, v)
    if hi is not None:
        v = min(hi, v)
    return v


def _full_ext(cfg):
    """Full frames format. JPG is much faster and is enough for SAM/matting input."""
    v = str((cfg or {}).get("full_frame_format", "jpg") or "jpg").lower().strip().lstrip(".")
    return "png" if v == "png" else "jpg"


def _jpeg_quality_to_ffmpeg_q(jpeg_q):
    # ffmpeg q:v: 2 = výborné, 31 = špatné. Ponecháváme rozumné minimum 2–12.
    try:
        q = int(jpeg_q)
    except Exception:
        q = 90
    return max(2, min(31, int((100 - q) / 100 * 31) or 3))


def _preview_scale_filter(max_edge):
    max_edge = max(240, int(max_edge or 960))
    return f"scale='if(gt(iw,ih),min({max_edge},iw),-2)':'if(gt(iw,ih),-2,min({max_edge},ih))'"


def _write_video_cv2(src_path, full_dir, prev_dir, jpeg_q=90, progress_cb=None, cfg=None, make_preview=True):
    """Fallback bez externího ffmpeg.exe. Dekóduje přes OpenCV a zapisuje JPG/PNG + preview JPG."""
    cap = cv2.VideoCapture(src_path)
    if not cap.isOpened():
        raise RuntimeError("Video se nepodařilo otevřít. Chybí FFmpeg a OpenCV ho také neumí načíst: %s" % src_path)

    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
    fps = float(cap.get(cv2.CAP_PROP_FPS) or 0) or 25.0
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    if w <= 0 or h <= 0:
        cap.release()
        raise RuntimeError("Nelze zjistit rozměry videa přes OpenCV: %s" % src_path)

    full_ext = _full_ext(cfg or {})
    full_jpg_q = _cfg_int(cfg or {}, "full_jpeg_quality", 95, 40, 100)
    prev_edge = _cfg_int(cfg or {}, "preview_max_long_edge", 960, 240, 4096)
    prev_q = _cfg_int(cfg or {}, "preview_jpeg_quality", jpeg_q, 40, 100)

    idx = 0
    full_jpg_params = [cv2.IMWRITE_JPEG_QUALITY, full_jpg_q]
    prev_jpg_params = [cv2.IMWRITE_JPEG_QUALITY, prev_q]

    # V70: dekódování je sekvenční, ale encode+zápis snímků běží ve vláknech
    # na pozadí (cv2.imwrite pouští GIL) — překrývá se s dekódováním dalšího framu.
    from concurrent.futures import ThreadPoolExecutor

    def _save(frame, i):
        if full_ext == "png":
            cv2.imwrite(os.path.join(full_dir, "%06d.png" % i), frame)
        else:
            cv2.imwrite(os.path.join(full_dir, "%06d.jpg" % i), frame, full_jpg_params)
        if make_preview:
            ph, pw = frame.shape[:2]
            le = max(pw, ph)
            if le > prev_edge:
                s = prev_edge / le
                prev = cv2.resize(frame, (int(pw * s), int(ph * s)), interpolation=cv2.INTER_AREA)
            else:
                prev = frame
            cv2.imwrite(os.path.join(prev_dir, "%06d.jpg" % i), prev, prev_jpg_params)

    pending = []
    with ThreadPoolExecutor(max_workers=max(2, min(8, (os.cpu_count() or 4) // 2))) as pool:
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            pending.append(pool.submit(_save, frame, idx))
            if len(pending) >= 16:  # drž RAM frontu krátkou
                pending.pop(0).result()

            idx += 1
            if progress_cb and total > 0 and (idx == 1 or idx % 20 == 0 or idx == total):
                progress_cb(min(1.0, idx / max(1, total)))
        for f in pending:
            f.result()

    cap.release()
    if idx <= 0:
        raise RuntimeError("Z videa se nepodařilo vyčíst žádný snímek: %s" % src_path)
    if progress_cb:
        progress_cb(1.0)
    return idx, w, h, fps


def extract_video(cfg, src_path, full_dir, prev_dir, jpeg_q=90, progress_cb=None, make_preview=True):
    os.makedirs(full_dir, exist_ok=True)
    os.makedirs(prev_dir, exist_ok=True)

    ffmpeg = _resolve_ffmpeg(cfg)
    w, h, fps = probe_video(cfg, src_path)

    full_ext = _full_ext(cfg)
    full_q = _jpeg_quality_to_ffmpeg_q(_cfg_int(cfg, "full_jpeg_quality", 95, 40, 100))
    prev_q = _jpeg_quality_to_ffmpeg_q(_cfg_int(cfg, "preview_jpeg_quality", jpeg_q, 40, 100))
    prev_edge = _cfg_int(cfg, "preview_max_long_edge", 960, 240, 4096)

    if ffmpeg:
        try:
            print(f"[extract] FFmpeg: {ffmpeg}")
            print(f"[extract] full={full_ext.upper()} preview={prev_edge}px JPG")

            # Rychlejší režim: full framy jako kvalitní JPG. SAM2 je přímo umí
            # a odpadá pozdější PNG -> JPG cache pro video predictor.
            # V70: full framy + náhledy v JEDNOM ffmpeg průchodu (dvě výstupní
            # cesty) — video se nedekóduje dvakrát.
            cmd = [ffmpeg, "-y", "-hide_banner", "-loglevel", "error", "-i", src_path]
            if full_ext == "png":
                cmd += ["-start_number", "0", os.path.join(full_dir, "%06d.png")]
            else:
                cmd += ["-q:v", str(full_q), "-start_number", "0",
                        os.path.join(full_dir, "%06d.jpg")]

            # Náhledy pro editor jen když je vyžádané zmenšení. Při full-quality
            # náhledu editor dostane plné framy (řeší run.py), tohle se přeskočí.
            if make_preview:
                scale = _preview_scale_filter(prev_edge)
                cmd += ["-vf", scale, "-q:v", str(prev_q),
                        "-start_number", "0", os.path.join(prev_dir, "%06d.jpg")]
            _run(cmd)

            n = len(glob.glob(os.path.join(full_dir, "*." + full_ext)))
            if n <= 0:
                raise RuntimeError(f"FFmpeg doběhl, ale nevznikly žádné {full_ext.upper()} snímky.")
            if progress_cb:
                progress_cb(1.0)
            return n, w, h, fps
        except Exception as e:
            print(f"[extract] FFmpeg extrakce selhala, přepínám na OpenCV fallback: {e}")
            # vyčisti případné rozpracované snímky, aby se nepomíchaly
            for pat in (os.path.join(full_dir, "*.png"), os.path.join(full_dir, "*.jpg"),
                        os.path.join(prev_dir, "*.jpg")):
                for p in glob.glob(pat):
                    try:
                        os.remove(p)
                    except Exception:
                        pass
    else:
        print("[extract] FFmpeg/ffprobe nenalezen. Používám OpenCV fallback.")

    return _write_video_cv2(src_path, full_dir, prev_dir, jpeg_q=jpeg_q, progress_cb=progress_cb, cfg=cfg, make_preview=make_preview)


def extract_sequence(cfg, src_path, full_dir, prev_dir, jpeg_q=90, make_preview=True):
    """
    src_path = jeden nahraný snímek. Pokud vedle něj na disku leží číslovaná
    sekvence (00000.png, 00001.png…), vezmeme celou. Jinak jednosnímkový job.
    """
    os.makedirs(full_dir, exist_ok=True)
    os.makedirs(prev_dir, exist_ok=True)

    src_dir = os.path.dirname(src_path)
    base = os.path.basename(src_path)
    ext = os.path.splitext(base)[1].lower()

    # zkus najít číslovanou sekvenci ve stejné složce
    seq = sorted(glob.glob(os.path.join(src_dir, "*" + ext)))
    if len(seq) <= 1:
        seq = [src_path]

    full_ext = _full_ext(cfg)
    full_jpg_q = _cfg_int(cfg, "full_jpeg_quality", 95, 40, 100)
    prev_edge = _cfg_int(cfg, "preview_max_long_edge", 960, 240, 4096)
    prev_q = _cfg_int(cfg, "preview_jpeg_quality", jpeg_q, 40, 100)

    w = h = 0
    for i, p in enumerate(seq):
        im = cv2.imread(p, cv2.IMREAD_UNCHANGED)
        if im is None:
            continue
        if im.ndim == 2:
            im = cv2.cvtColor(im, cv2.COLOR_GRAY2BGR)
        if im.shape[2] == 4:
            im = cv2.cvtColor(im, cv2.COLOR_BGRA2BGR)
        h, w = im.shape[:2]
        if full_ext == "png":
            cv2.imwrite(os.path.join(full_dir, "%06d.png" % i), im)
        else:
            cv2.imwrite(os.path.join(full_dir, "%06d.jpg" % i), im, [cv2.IMWRITE_JPEG_QUALITY, full_jpg_q])
        # náhled (jen když je vyžádané zmenšení)
        if make_preview:
            le = max(w, h)
            if le > prev_edge:
                s = prev_edge / le
                prev = cv2.resize(im, (int(w * s), int(h * s)), interpolation=cv2.INTER_AREA)
            else:
                prev = im
            cv2.imwrite(os.path.join(prev_dir, "%06d.jpg" % i),
                        prev, [cv2.IMWRITE_JPEG_QUALITY, prev_q])

    n = len(glob.glob(os.path.join(full_dir, "*." + full_ext)))
    return n, w, h, 25.0


def zip_previews(prev_dir, zip_path):
    """Zabalí JPG náhledy pro upload do editoru."""
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_STORED) as z:
        for p in sorted(glob.glob(os.path.join(prev_dir, "*.jpg"))):
            z.write(p, os.path.basename(p))
    return zip_path
