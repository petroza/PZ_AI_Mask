@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0.."
set "HERE=%CD%"
set "PHPEXE=%HERE%\runtime\php\php.exe"
set "PHPINI=%HERE%\runtime\php\php.ini"
echo.
echo ============================================================
echo   PZ MASK frontend
echo   URL: http://127.0.0.1:8080
echo ============================================================
echo.
"%PHPEXE%" -c "%PHPINI%" -S 127.0.0.1:8080 -t "%HERE%" "%HERE%\router.php"
pause
