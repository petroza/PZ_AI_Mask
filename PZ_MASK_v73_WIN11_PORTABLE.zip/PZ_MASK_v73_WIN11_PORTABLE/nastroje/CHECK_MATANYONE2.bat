@echo off
setlocal
cd /d "%~dp0.."
set "ROOT=%CD%"
set "CONDADIR=%LocalAppData%\MaskStudioRT\miniconda"
set "PY=%CONDADIR%\envs\maskstudio\python.exe"
if not exist "%PY%" (
  echo [ERROR] Python env not found. Run nastroje\INSTALL_NO_POWERSHELL.bat first.
  pause
  exit /b 1
)
pushd "%ROOT%\worker"
"%PY%" -c "import torch; print('Torch:', torch.__version__, 'CUDA:', torch.cuda.is_available(), torch.cuda.get_device_name(0) if torch.cuda.is_available() else '-'); from matanyone2 import MatAnyone2, InferenceCore; print('MatAnyone2: OK')"
if errorlevel 1 (
  echo.
  echo MatAnyone2 is not active. High Quality will use fallback.
) else (
  echo.
  echo MatAnyone2 is active. High Quality refine can use real video matting.
)
popd
pause
