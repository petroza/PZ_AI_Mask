@echo off
REM Removes Windows Mark-of-the-Web from extracted files, then starts installer.
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0.."
echo.
echo  Unblocking Mask Studio files...
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%CD%' -Recurse -File | ForEach-Object { try { Unblock-File -LiteralPath $_.FullName -ErrorAction SilentlyContinue } catch {} }"
echo.
echo  Starting installer...
call "%~dp0..\install.bat" %*
