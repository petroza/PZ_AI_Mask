@echo off
REM ====================================================================
REM  Mask Studio - UNINSTALL
REM  Removes this local installation folder.
REM ====================================================================
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"

set "HERE=%~dp0"
if "%HERE:~-1%"=="\" set "HERE=%HERE:~0,-1%"

echo.
echo  ============================================================
echo    Mask Studio - uninstall
echo  ============================================================
echo.
echo  This will remove the whole folder:
echo    %HERE%
echo.
echo  It removes:
echo    - app files
echo    - runtime
echo    - downloaded Python packages
echo    - downloaded models
echo    - local database/jobs/outputs stored inside this folder
echo.
echo  Close FRONTEND / WORKER windows before continuing.
echo.
choice /C YN /M "Really uninstall Mask Studio from this folder"
if errorlevel 2 exit /b 0

echo.
echo  Stopping local Mask Studio processes on port 8080 if found...
for /f "tokens=5" %%P in ('netstat -ano ^| findstr ":8080 " ^| findstr "LISTENING"') do (
  taskkill /PID %%P /F >nul 2>nul
)

echo.
echo  Scheduling folder removal...
echo  The uninstall window will close and the folder will be deleted.

set "PARENT=%~dp0.."
set "TARGET=%HERE%"

start "" cmd /c "timeout /t 2 /nobreak >nul & cd /d "%PARENT%" & rmdir /s /q "%TARGET%""

exit /b 0
